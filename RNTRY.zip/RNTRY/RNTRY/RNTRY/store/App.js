import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import 'react-native-gesture-handler'

import MaterialTabbedPageNavigator from './Pages/MaterialTabbedPageNavigator';
import LoginPage from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage';
import UserContextProvider from './Contexts/UserContextProvider';
import WarningLightsContextProvider from './Contexts/WarningLightsContextProvider';
import WelcomePage from './Pages/WelcomePage';
import AddCar from './Pages/AddCar';
import ProfilePage from './Pages/ProfilePage';
import ProfileEachCar from './Pages/ProfileEachCar';
import TahzukaCar from './Pages/TahzukaCar';
import BulbsCar from './Pages/BulbsCar';
import AddMaintenance from './Pages/AddMaintenance';
import ProfileEachMaintenance from './Pages/ProfileEachMaintenance';



const Stack = createNativeStackNavigator();

function App() {
  return (
    <SafeAreaProvider>
      <UserContextProvider>
        <WarningLightsContextProvider>
          <AppContent />
        </WarningLightsContextProvider>
      </UserContextProvider>
    </SafeAreaProvider>
  );
}

function AppContent() {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="WelcomePage" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="WelcomePage" component={WelcomePage} />
          <Stack.Screen name="LoginPage" component={LoginPage} />
          <Stack.Screen name="RegisterPage" component={RegisterPage} />
          <Stack.Screen name="TabbedPageNavigator" component={MaterialTabbedPageNavigator} />
          <Stack.Screen name="AddCar" component={AddCar} />
          <Stack.Screen name="ProfilePage" component={ProfilePage} />
          <Stack.Screen name="ProfileEachCar" component={ProfileEachCar} />
          <Stack.Screen name="TahzukaCar" component={TahzukaCar} />
          <Stack.Screen name="BulbsCar" component={BulbsCar} />
          <Stack.Screen name="AddMaintenance" component={AddMaintenance} />
          <Stack.Screen name="ProfileEachMaintenance" component={ProfileEachMaintenance} />

          

        </Stack.Navigator>
      </NavigationContainer>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});

export default App;
