import React, { createContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const UserContext = createContext();

export default function UserContextProvider(props) {
  const [users, setUsers] = useState([]);
  const [carsFetched, setCarsFetched] = useState(false); // New state variable

  const [currentUser, setCurrentUser] = useState(null);


  useEffect(() => {
    const loadUsers = async () => {
      try {
        const response = await fetch('https://socialgarage.bsite.net/api/users');
        const data = await response.json();
        setUsers(data);
      } catch (error) {
        console.error(error);
      }
    };
    loadUsers();
  }, []);




  useEffect(() => {
    const updateUsers = async () => {
      try {
        await fetch('https://socialgarage.bsite.net/api/users', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(users),
        });
      } catch (error) {
        console.error(error);
      }
    };
    updateUsers();
  }, [users]);






  const fromRegisterToUsersList = async (email, name, password) => {
    const newUser = { email: email.toLowerCase(), name, password };
    try {
      const response = await fetch('https://socialgarage.bsite.net/api/users/AddUser', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(newUser),
      });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      setUsers([...users, newUser]);
      return true; // User added successfully

    } catch (error) {
      return false;
    }
  };








  const fromLoginToCheckIfExist = async (userEmail, password) => {
    try {
      const response = await fetch('https://socialgarage.bsite.net/api/users/authenticate', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ email: userEmail.toLowerCase(), password }),
      });

      if (!response.ok) {
        return false;
      }

      const user = await response.json();
      const cars = []; // Replace this with your actual array of objects

      setCurrentUser({ ...user, cars });

      return true;



    } catch (error) {
      return false;
    }
  };



  const addCarToUser = async (CarDetails) => {
    setCarsFetched(false);

    try {
      const response = await fetch(`https://socialgarage.bsite.net/api/users/${currentUser._id}/addcar`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(CarDetails),
      });


      alert(response.status)
      if (!response.ok) {
        return false;
      }

      const carReturning = await response.json();
      // setCurrentUser(...cars, carReturning);
      return true; // Car added successfully


    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };





  const getCarsByUserId = async (userId) => {
    if (carsFetched) {
      // Cars have already been fetched, avoid fetching again to prevent an infinite loop
      return currentUser.cars;
    }

    try {
      const response = await fetch(`https://socialgarage.bsite.net/api/users/${userId}/cars`, {
        method: 'GET',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
      });

      if (!response.ok) {
        return [];
      }

      const cars = await response.json();
      // Now fetch the Tahzuka for each car and add it to the car object
      const carsWithTahzuka = await Promise.all(
        cars.map(async (car) => {
          const tahzukaResponse = await fetch(`https://socialgarage.bsite.net/api/users/${car.carNumber}/tahzuka`);
          if (tahzukaResponse.ok) {
            const tahzukaData = await tahzukaResponse.json();
            car.tahzuka = tahzukaData;
          } else {
            car.tahzuka = [];
          }
          return car;
        })
      );

      setCurrentUser((prevUser) => ({ ...prevUser, cars: carsWithTahzuka }));
      setCarsFetched(true); // Set the flag to true after fetching cars

      return carsWithTahzuka;
    } catch (error) {
      console.error(error);
      return [];
    }
  };








  const updateCarMileage = async (carNumber, mileage) => {
    try {
      const response = await fetch(`https://socialgarage.bsite.net/api/users/${carNumber}/updateCarKM`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(mileage),
      });
      if (!response.ok) {
        throw new Error('Failed to update');
      }

      alert("עודכן בהצלחה")
      return true;
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };




  const updateCarTest = async (carNumber, newTest) => {
    try {
      const response = await fetch(`https://socialgarage.bsite.net/api/users/${carNumber}/updateTest`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(newTest),
      });
      if (!response.ok) {
        throw new Error('Failed to update');
      }

      alert("עודכן בהצלחה")
      return true;
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };





  const addMaintenanceToUser = async (carNumber, tahzuka) => {
    try {
      const response = await fetch(`https://socialgarage.bsite.net/api/users/${carNumber}/addTahzuka`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(tahzuka),
      });

      if (!response.ok) {
        throw new Error('Failed to add');
      }

      alert("התווסף בהצלחה")
      return true;
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };



  // Function to transfer a car from one user to another
  const transferCar = async (currentOwnerEmail, newOwnerEmail, carNumber) => {
    try {
      const response = await fetch('https://socialgarage.bsite.net/api/users/transferCar', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ currentOwnerEmail, newOwnerEmail, carNumber }),
      });

      if (!response.ok) {
        throw new Error('Failed to transfer car.');
      }

      const cars = await response.json();
      setCurrentUser((prevUser) => ({ ...prevUser, cars: cars }));


      return true; // Car transferred successfully
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };




  const deleteCar = async (currentOwnerEmail, newOwnerEmail, carNumber) => {
    try {
      const response = await fetch('https://socialgarage.bsite.net/api/users/transferCar', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ currentOwnerEmail, newOwnerEmail, carNumber }),
      });

      if (!response.ok) {
        throw new Error('Failed to transfer car.');
      }

      const cars = await response.json();
      setCurrentUser((prevUser) => ({ ...prevUser, cars: cars }));


      return true; // Car transferred successfully
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };




  return (
    <UserContext.Provider value={{ updateCarTest, updateCarMileage, getCarsByUserId, deleteCar, currentUser, transferCar, addMaintenanceToUser, addCarToUser, fromRegisterToUsersList, fromLoginToCheckIfExist, currentUser }}>
      {props.children}
    </UserContext.Provider>
  );
}
