import React, { useContext, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { UserContext } from '../Contexts/UserContextProvider';

export default function ProfilePage() {
  const { currentUser,getCarsByUserId } = useContext(UserContext);
  const navigation = useNavigation();

  const navigateToProfileEachCar = (car) => {
    navigation.navigate('ProfileEachCar', { carData: car });
  };



  useEffect(() => {
    // Make sure currentUser is available before calling the function
    if (currentUser) {
      getCarsByUserId(currentUser._id);
    }
  }, [currentUser]);

  return (
    <ScrollView>
      <View style={styles.container}>
        <Text style={styles.heading}>Welcome, {currentUser ? currentUser.name : ''}!</Text>

        <Text style={styles.sectionHeading}>הרכבים שלך: </Text>

        {currentUser && currentUser.cars && currentUser.cars.length > 0 ? (
          currentUser.cars.map((car, index) => (
            <TouchableOpacity
              key={index}
              style={styles.carContainer}
              onPress={() => navigateToProfileEachCar(car)}
            >
              <Image style={styles.carImage} source={{ uri: car.image }} />
              <Text style={styles.carName}>{car.manufacturer}, {car.model}{car.nickname ? `, ${car.nickname}` : ''}</Text>
            </TouchableOpacity>
          ))
        ) : (
          <Text style={styles.noCarsText}>No cars available</Text>
        )}

        <TouchableOpacity
          style={styles.addCarButton}
          onPress={() => navigation.navigate('AddCar')}
        >
          <Text style={styles.addCarButtonText}>הוספת רכב</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  sectionHeading: {
    fontSize: 18,
    marginTop: 20,
    marginBottom: 10,
    textAlign: "right",
  },
  carContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    backgroundColor: '#ff8837',
    borderRadius: 42,
    justifyContent: 'space-between',
    paddingRight: '5%',
  },
  carImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  carName: {
    fontSize: 16,
  },
  noCarsText: {
    fontSize: 16,
    fontStyle: 'italic',
  },
  addCarButton: {
    marginTop: 20,
    marginBottom: 20,
    padding: 10,
    backgroundColor: '#ff5f04',
    borderRadius: 10,
    alignSelf: 'center',
  },
  addCarButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
