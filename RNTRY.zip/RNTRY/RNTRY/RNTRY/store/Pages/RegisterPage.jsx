import React, { useState, useContext, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';

export default function RegisterPage(props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');

  const { fromRegisterToUsersList } = useContext(UserContext);

  const slideAnim = useRef(new Animated.Value(5)).current;

  useEffect(() => {
    // Start the slide-in animation when the component mounts
    Animated.timing(slideAnim, {
      toValue: 0,
      duration: 1200,
      useNativeDriver: true,
    }).start();
  }, [slideAnim]);


  const handleRegister = async () => {

    if (email.trim() === '' || password.trim() === '' || confirmPassword.trim() === '' || name.trim() === '') {
      alert('Please fill in all the fields');
      return;
    }

    if (password !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    const userAdded = await fromRegisterToUsersList(email, name, password);
    if (userAdded) {
      alert("User successfully created");
      props.navigation.navigate('LoginPage');
    }
    else if (!userAdded) {
      alert("מייל תפוס");
    }
    else {
      alert("משהו לא עובד, נסה שנית")
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>הרשמה</Text>


      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, 100],
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="מייל"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          textAlign="right"
        />
      </Animated.View>


      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -100],
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="שם מלא"
          keyboardType="default"
          value={name}
          onChangeText={setName}
          textAlign="right"
        />
      </Animated.View>


      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, 100],
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="סיסמה"
          secureTextEntry={true}
          value={password}
          onChangeText={setPassword}
          textAlign="right"
        />
      </Animated.View>

      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -100],
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="אימות סיסמה"
          secureTextEntry={true}
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          textAlign="right"
        />
      </Animated.View>


      <TouchableOpacity
        style={styles.button}
        onPress={handleRegister}
      >
        <Text style={styles.buttonText}>הרשמה</Text>
      </TouchableOpacity>


      <View style={styles.registerContainer}>
        <TouchableOpacity
          onPress={() => props.navigation.navigate('LoginPage')}
        >
          <Text style={styles.registerButton}> להתחברות </Text>
        </TouchableOpacity>
        <Text style={styles.registerText}>כבר יש לך חשבון? </Text>
      </View>

    </View>
  )
}





const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'top',
    paddingTop: "20%",
  },
  heading: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 40,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderColor: '#ff5f04',
    borderRadius: 20,
    padding: 10,
    marginBottom: 20,
    width: '80%',
  },
  input: {
    width: '100%',
  },
  button: {
    backgroundColor: '#ff5f04',
    borderRadius: 20,
    padding: 10,
    width: '80%',
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: 'black',
    fontWeight: 'bold',
  },
  link: {
    marginTop: 20,
  },
  linkText: {
    color: '#007bff',
    textDecorationLine: 'underline',
  },
  registerContainer: {
    flexDirection: 'row',
    marginTop: 20,
  },
  registerText: {
    marginRight: 10,
  },
  registerButton: {
    color: '#ff5f04',
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
});