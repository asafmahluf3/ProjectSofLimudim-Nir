import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, Image } from 'react-native';
import cheerio from 'cheerio';

const CarDetails = () => {
    const [web, setWeb] = useState("https://www.find-car.co.il/car/private/");
    const [inputValue, setInputValue] = useState("");
    const [data, setData] = useState(null);


    const addToWeb = () => {
        const updatedWeb = web + inputValue;
        setWeb(updatedWeb);
        setInputValue("");
    };


    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const response = await fetch(web);
            const html = await response.text();
            const $ = cheerio.load(html);
            const imageUrl = $('div.image img').attr('src');
            setData(imageUrl);
        } catch (error) {
            console.error(error);
        }
    };


    return (
        <View>
            <TextInput
                placeholder="הזן ערך"
                value={inputValue}
                onChangeText={setInputValue}
            />






            <Button title="הוסף ל־web" onPress={addToWeb} />

            <Text>{web}</Text>

            <Button title="Start Fetch" onPress={fetchData} />

            {data ? (
                <View>
                    <Text>{data}</Text>
                    <Image source={{ uri: data }} style={{ width: 200, height: 200 }} />
                </View>
            ) : (
                <Text>Loading data...</Text>
            )}
        </View>
    );
};

export default CarDetails;
