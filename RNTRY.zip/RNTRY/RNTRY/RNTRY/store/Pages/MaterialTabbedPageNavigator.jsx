import React from 'react';
import { Text } from 'react-native';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { FontAwesome } from 'react-native-vector-icons';

import ProfilePage from './ProfilePage';
import BulbsCar from './BulbsCar';

const Tab = createMaterialBottomTabNavigator();

export default function MaterialTabbedPageNavigator() {
    return (
        <Tab.Navigator
            initialRouteName="Profile"
            activeColor="#55ff00"
            inactiveColor="black"
            barStyle={{ backgroundColor: '#ff5f04', height: "12%" }}
        >




            <Tab.Screen
                name="Bulbs Car"
                component={BulbsCar}
                options={{
                    tabBarLabel: (
                        <Text style={{ fontSize: 12, fontWeight: '700', color: 'white' }}>
                            נורות
                        </Text>
                    ),
                    tabBarIcon: ({ color }) => (
                        <FontAwesome name="lightbulb-o" color={"black"} size={25} />
                    ),
                }}
            />

            <Tab.Screen
                name="Profile"
                component={ProfilePage}
                options={{
                    tabBarLabel: (
                        <Text style={{ fontSize: 12, fontWeight: '700', color: 'white' }}>
                            איזור אישי
                        </Text>
                    ),
                    tabBarIcon: ({ color }) => (
                        <FontAwesome name="user" color={"black"} size={25} />
                    ),
                }}
            />




        </Tab.Navigator>
    );
}
