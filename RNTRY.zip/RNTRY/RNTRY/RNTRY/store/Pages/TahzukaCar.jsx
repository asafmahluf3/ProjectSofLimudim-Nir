import React, { useContext, useState } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';

export default function TahzukaCar({ route }) {
  const { carData } = route.params;
  const navigation = useNavigation();

  const navigateToProfileEachMaintenance = (maintenance) => {
    navigation.navigate('ProfileEachMaintenance', { carData: maintenance });
  };

  const AddMaintenance = () => {
    navigation.navigate('AddMaintenance', { carData });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>תחזוקת רכב</Text>

      {/* Update the mapping to use the original data */}
      {carData.tahzuka.length > 0 ? (
        <ScrollView>
          {carData.tahzuka.map((maintenance, index) => (
            <TouchableOpacity
              key={index}
              style={styles.carContainer}
              onPress={() => navigateToProfileEachMaintenance(maintenance)}
            >
              <View style={styles.carDetailsContainer}>
                <Text style={styles.carDate}>{maintenance.date} <Text style={styles.hrCombine}>|</Text> </Text>
                <Text style={styles.carName}>{maintenance.name}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      ) : (
        <Text style={styles.noCarsText}>אין טיפולים לרכב זה</Text>
      )}

      <TouchableOpacity style={styles.addCarButton} onPress={AddMaintenance}>
        <Text style={styles.addCarButtonText}>הוסף טיפול</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  sectionHeading: {
    fontSize: 18,
    marginTop: 20,
    marginBottom: 10,
    textAlign: "right",
  },
  carContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    backgroundColor: '#ff8837',
    borderRadius: 42,
    height: 50,
    justifyContent: 'center',
    textAlign: 'center',
  },
  carImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  carDetailsContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  carName: {
    fontSize: 16,
    flex: 1,
    textAlign: 'right',
    paddingRight: '7%',
  },
  carDate: {
    fontSize: 16,
    textAlign: 'left',
    flex: 1,
    paddingLeft: "5%",
  },
  noCarsText: {
    fontSize: 16,
    fontStyle: 'italic',
  },
  addCarButton: {
    marginTop: 20,
    marginBottom: 20,
    padding: 10,
    backgroundColor: '#ff5f04',
    borderRadius: 10,
    alignSelf: 'center',
  },
  addCarButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  hrCombine: {
    fontSize: 20,
  },
  yearFilterButton: {
    alignSelf: 'flex-end',
    paddingVertical: 10,
  },
  yearFilterButtonText: {
    fontSize: 16,
    color: '#007AFF', // or any other color you prefer
    alignSelf: 'center'
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  yearMenu: {
    backgroundColor: '#e2e4e7',
    borderRadius: 10,
    marginHorizontal: 20,
    paddingVertical: 10,
    maxHeight: 300,

  },
  yearMenuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    marginBottom: 10,

  },
  yearMenuHeaderText: {
    fontSize: 16,
    color: 'black',
    fontWeight: 'bold',
  },
  closeButton: {
    alignSelf: 'flex-end',
    padding: 10,
  },
  closeButtonText: {
    fontSize: 16,
    color: 'black',
    fontWeight: 'bold',
  },
  yearMenuItem: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    marginHorizontal: 5,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 5, // Add some margin to separate the years

  },
  selectedYearMenuItem: {
    backgroundColor: '#007AFF', // or any other color you prefer
  },
  yearText: {
    fontSize: 16,
    color: 'black',
    textAlign: 'center', // Center the year text

  },

});
