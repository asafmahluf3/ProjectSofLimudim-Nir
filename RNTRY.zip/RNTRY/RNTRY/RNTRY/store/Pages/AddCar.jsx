import React, { useContext, useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
  Alert,
  Image,
  KeyboardAvoidingView,
  ActivityIndicator,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import { ScrollView } from 'react-native-gesture-handler';
import cheerio from 'cheerio';



export default function AddCar() {
  const navigation = useNavigation();
  const { addCarToUser } = useContext(UserContext);

  const [carNumber, setCarNumber] = useState('');
  const [carNumberEditable, setCarNumberEditable] = useState(true); // New state variable
  const [manufacturer, setManufacturer] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [mileage, setMileage] = useState('');
  const [license, setLicense] = useState('');
  const [test, setTest] = useState('');
  const [image, setImage] = useState(null);
  const [nickname, setNickname] = useState('');
  const [isUploading, setIsUploading] = useState(false);



  /* שליפת נתונים מאתר */    /* שליפת נתונים מאתר */   /* שליפת נתונים מאתר */   /* שליפת נתונים מאתר */
  const [web, setWeb] = useState("https://www.find-car.co.il/car/private/");
  const [data, setData] = useState(null);

  const pattern = /[0-9\\\-.,/]/g;



  const fetchData = async () => {
    try {

      setManufacturer("טוען נתונים, אנא המתן...");
      setModel("טוען נתונים, אנא המתן...");
      setYear("טוען נתונים, אנא המתן...");
      setTest("טוען נתונים, אנא המתן...");



      const response = await fetch(web);
      const html = await response.text();
      const $ = cheerio.load(html);
      const manufacturerFetch = $('.side_one ul.items li:contains("שם תוצר") strong').text().trim();
      const modelFetch = $('.side_one ul.items li:contains("כינוי מסחרי") strong').text().trim();
      const yearFetch = $('.side_one ul.items li:contains("שנת יצור") strong').text().trim();
      const testFetch = $('ul.items li.has_more_detials_conti form strong.has_more_detials').text().trim();
      const filteredTest = testFetch.match(pattern).join('');

      setManufacturer(manufacturerFetch);
      setModel(modelFetch);
      setYear(yearFetch);
      setTest(filteredTest);



    } catch (error) {
      console.error(error);
    }
  };








  const handleAddCar = async () => {
    if (isNaN(carNumber) || parseInt(carNumber) !== Number(carNumber)) {
      Alert.alert('Error', 'Car number must contain only numbers');
      return;
    }

    if (!image) {
      Alert.alert('Error', 'Please select an image');
      return;
    }

    const newCar = {
      manufacturer: manufacturer,
      model: model,
      image: image,
      carNumber: carNumber,
      year: year,
      hand: license,
      currentMileage: mileage,
      testValidity: test,
      nickname: nickname,
    };

    const success = await addCarToUser(newCar);

    if (success) {
      // Reset the input fields
      setCarNumber('');
      setManufacturer('');
      setModel('');
      setYear('');
      setMileage('');
      setLicense('');
      setTest('');
      setImage(null);
      setNickname('');
      navigation.navigate('ProfilePage', { newCar });
    } else {
      Alert.alert('Error', 'Failed to add car');
    }
  };




  /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */
  const openImagePickerAsync = async () => {
    if (Platform.OS !== 'web') {
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (permissionResult.granted === false) {
        alert('Permission to access media library is required!');
        return;
      }
    }

    Alert.alert(
      'Select Image Source',
      'Choose the source of the image',
      [
        {
          text: 'Camera',
          onPress: () => launchCamera(),
        },
        {
          text: 'Gallery',
          onPress: () => launchGallery(),
        },
        {
          text: 'Cancel',
          style: 'cancel',
        },
      ],
      { cancelable: true }
    );
  };




  const launchCamera = async () => {
    let permissionResult = await ImagePicker.requestCameraPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("Permission to access the camera is required!");
      return;
    }

    let pickerResult = await ImagePicker.launchCameraAsync({ base64: true, quality: 1.0 });

    if (!pickerResult.canceled) {
      await ImageUploader(pickerResult.assets[0].base64);
    }
  };





  //ask for permisstion
  const launchGallery = async () => {
    let permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("Permission to access camera roll is required!");
      return;
    }

    let pickerResult = await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 1.0 });

    if (!pickerResult.canceled) {
      await ImageUploader(pickerResult.assets[0].base64);
    }
  };


  const ImageUploader = async (uri) => {
    try {
      setIsUploading(true); // Set isUploading to true while the image is being uploaded


      const response = await fetch(`https://socialgarage.bsite.net/api/users/upload`, {
        method: "POST",
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(uri),
      });
      alert(response.status)

      if (!response.ok) {
        throw new Error("Failed to upload image");
      } else {
        const data = await response.json();
        setImage(data.imageUrl); // Assuming setImage is a state update function to store the image URL in the client
      }

      return;
    } catch (err) {
      console.log(err);
    } finally {
      setIsUploading(false); // Ensure isUploading is set back to false even if an error occurs
    }
  };




  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const dismissKeyboard = () => {
    Keyboard.dismiss();
  };

  return (
    <KeyboardAvoidingView // לצורך נראות האינפוטים והורדת המקלדת
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1 }}>
      <ScrollView>
        <TouchableWithoutFeedback onPress={dismissKeyboard}>
          <View style={styles.container}>
            <Text style={styles.heading}>הוספת רכב</Text>


            <Text style={styles.upText}>מספר רכב</Text>

            <View style={styles.carNumberInputContainer}>

              <TouchableOpacity style={styles.confirmButton} onPress={() => {
                fetchData();
                setCarNumberEditable(false); // Disable car number input
              }}
                disabled={!carNumberEditable} // Disable the button if input is disabled
              >
                <Text style={styles.confirmButtonText}>אישור</Text>
              </TouchableOpacity>


              <TextInput
                style={styles.inputNumberCar}
                placeholder="מספר רכב"
                keyboardType="numeric"
                value={carNumber}
                onChangeText={setCarNumber}
                textAlign="right"
                onBlur={() => setWeb(web + carNumber)}
                editable={carNumberEditable} // Set editable based on state
              />
            </View>

            <Text style={styles.upText}>יצרן</Text>
            <TextInput
              style={styles.input}
              placeholder="יצרן"
              value={manufacturer}
              onChangeText={setManufacturer}
              textAlign="right"
              editable={false}
            />

            <Text style={styles.upText}>דגם</Text>
            <TextInput
              style={styles.input}
              placeholder="דגם"
              value={model}
              onChangeText={setModel}
              textAlign="right"
              editable={false}
            />

            <Text style={styles.upText}>שנה</Text>
            <TextInput
              style={styles.input}
              placeholder="שנה"
              keyboardType="numeric"
              value={year}
              onChangeText={setYear}
              textAlign="right"
              editable={false}
            />

            <Text style={styles.upText}>תוקף טסט</Text>

            <TextInput
              style={styles.input}
              placeholder="תוקף טסט"
              value={test}
              onChangeText={setTest}
              textAlign="right"
              editable={false}
            />
            <Text style={styles.upText}>יד</Text>
            <TextInput
              style={styles.input}
              placeholder="יד נוכחית"
              keyboardType="numeric"
              value={license}
              onChangeText={setLicense}
              textAlign="right"
            />
            <Text style={styles.upText}>ק"מ</Text>
            <TextInput
              style={styles.input}
              placeholder="ק&quot;מ עדכני"
              keyboardType="numeric"
              value={mileage}
              onChangeText={setMileage}
              textAlign="right"
            />

            <Text style={styles.upText}>כינוי רכב</Text>
            <TextInput
              style={styles.input}
              placeholder="כינוי רכב"
              value={nickname}
              onChangeText={setNickname}
              textAlign="right"
            />

            {isUploading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#ff5f04" />
                <Text style={styles.loadingText}>מעלה תמונה, אנא המתן...</Text>
              </View>
            ) : (
              <TouchableOpacity style={styles.imageButton} onPress={openImagePickerAsync}>
                <Text style={styles.buttonText}>בחר תמונה</Text>
              </TouchableOpacity>
            )}


            {image && (
              <View style={styles.imageContainer}>
                <Text style={styles.imageText}>Selected Image:</Text>
                <Image source={{ uri: image }} style={styles.selectedImage} />
              </View>
            )}

            <TouchableOpacity style={styles.addButton} onPress={handleAddCar}>
              <Text style={styles.addButtonText}>הוסף רכב</Text>
            </TouchableOpacity>
          </View>
        </TouchableWithoutFeedback>
      </ScrollView>
    </KeyboardAvoidingView>

  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    width: "100%",
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: "center",
  },
  carNumberInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: "100%",
  },
  confirmButton: {
    padding: 10,
    backgroundColor: '#ff5f04',
    borderRadius: 10,
    width: "25%",
    alignItems: "center",
    marginBottom: 11,

  },
  confirmButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',

  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
    borderColor: '#ff5f04',
    fontWeight: 'bold',
  },
  inputNumberCar: {
    marginLeft: 17.5,
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
    borderColor: '#ff5f04',
    fontWeight: 'bold',
    width: "70%",
  },
  imageButton: {
    marginTop: 10,
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#fff',  // שנה את צבע הרקע ללבן
    borderRadius: 5,  // שנה את הסגנון לעגול
    borderWidth: 1,  // הוסף מסגרת
    borderColor: '#ff5f04',  // צבע המסגרת
    fontWeight: 'bold',
    textAlign: 'center',  // מרכז את הטקסט באמצעות מיקום הטקסט
  },
  buttonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  imageText: {
    fontSize: 14,
    marginBottom: 5,
    textAlign: 'center',
  },
  selectedImage: {
    width: 200,
    height: 200,
    borderRadius: 10,
  },
  addButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#ff5f04',
    borderRadius: 10,
    alignSelf: 'center',
  },
  addButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  upText: {
    textAlign: "right",
    marginBottom: 3,
    marginRight: 3,
    fontWeight: 'bold',
  },
  loadingContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  loadingText: {
    fontSize: 14,
    marginTop: 5,
    textAlign: 'center',
  },
});