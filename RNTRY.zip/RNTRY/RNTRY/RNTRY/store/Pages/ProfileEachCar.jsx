import React, { useState, useContext, useEffect, useRef } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Alert, Modal, Button } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import cheerio from 'cheerio';
import { useNavigation } from '@react-navigation/native';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: false,
        shouldSetBadge: false,
    }),
});

// Can use this function below OR use Expo's Push Notification Tool from: https://expo.dev/notifications
async function sendPushNotification(expoPushToken) {
    const message = {
        to: expoPushToken,
        sound: 'default',
        title: 'Original Title',
        body: 'And here is the body!',
        data: { someData: 'goes here' },
    };

    await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
            Accept: 'application/json',
            'Accept-encoding': 'gzip, deflate',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(message),
    });
}

async function registerForPushNotificationsAsync() {
    let token;
    if (Device.isDevice) {
        const { status: existingStatus } = await Notifications.getPermissionsAsync();
        let finalStatus = existingStatus;
        if (existingStatus !== 'granted') {
            const { status } = await Notifications.requestPermissionsAsync();
            finalStatus = status;
        }
        if (finalStatus !== 'granted') {
            alert('Failed to get push token for push notification!');
            return;
        }
        token = (await Notifications.getExpoPushTokenAsync()).data;
        console.log(token);
    } else {
        alert('Must use physical device for Push Notifications');
    }

    if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('default', {
            name: 'default',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
        });
    }
    return token;
}



export default function ProfileEachCar({ route }) {
    const navigation = useNavigation();
    const { carData } = route.params;
    const { updateCarMileage, updateCarTest, deleteCar, transferCar, currentUser } = useContext(UserContext);
    const [mileageState, setMileage] = useState(carData.currentMileage);
    const [modalVisible, setModalVisible] = useState(false);
    const [testValidity, setTestValidity] = useState(carData.testValidity);
    const [web, setWeb] = useState("https://www.find-car.co.il/car/private/" + carData.carNumber);
    const [newOwnerEmail, setNewOwnerEmail] = useState('');

    const [expoPushToken, setExpoPushToken] = useState('');
    const [notification, setNotification] = useState(false);
    const notificationListener = useRef();
    const responseListener = useRef();

    useEffect(() => {
        registerForPushNotificationsAsync().then(token => setExpoPushToken(token));

        notificationListener.current = Notifications.addNotificationReceivedListener(notification => {
            setNotification(notification);
        });

        responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
            console.log(response);
        });

        return () => {
            Notifications.removeNotificationSubscription(notificationListener.current);
            Notifications.removeNotificationSubscription(responseListener.current);
        };
    }, []);



    useEffect(() => {
        // Update the mileage in the route params to reflect the latest value
        route.params.carData.currentMileage = mileageState;
    }, [mileageState]);

    useEffect(() => {
        // Update the testValidity in the route params to reflect the latest value
        route.params.carData.testValidity = testValidity;
    }, [testValidity]);

    const updateMileage = () => {
        Alert.prompt('עדכון ק"מ', 'הכנס ק"מ מעודכן:', (newMileage) => {
            const mileage = parseFloat(newMileage);

            if (!isNaN(mileage)) {
                if (mileage >= carData.currentMileage) {
                    updateCarMileage(carData.carNumber, mileage);
                    setMileage(mileage);

                    sendPushNotification(expoPushToken);

                } else {
                    Alert.alert('ק"מ לא תקין', 'אנא הכנס ק"מ גדול מקודמו');
                }
            } else {
                Alert.alert('ק"מ לא תקין', 'אנא הכנס ספרות בלבד');
            }
        });
    };

    const updateTest = async () => {
        try {
            const response = await fetch(web);
            const html = await response.text();
            const $ = cheerio.load(html);
            const testFetch = $('ul.items li.has_more_detials_conti form strong.has_more_detials').text().trim();


            const textToRemove = 'חידוש רישיון בקליק';
            const updatedTestFetch = testFetch.replace(textToRemove, '').trim();


            if (updatedTestFetch === testValidity) {
                alert("לא התעדכן, במקרה ועשית טסט לוקח שבועיים להתעדכן")
            } else if (updatedTestFetch === null || updatedTestFetch === undefined || updatedTestFetch === '') {
                alert("יש בעיה כלשהי? צור איתנו קשר")
            } else {
                setTestValidity(updatedTestFetch);
                updateCarTest(carData.carNumber, updatedTestFetch);
            }
        } catch (error) {
            console.error(error);
        }
    };

    const deleteCarConfirmation = async () => {
        try {
            Alert.alert(
                'מחיקת רכב',
                'האם אתה בטוח שברצונך למחוק את הרכב?',
                [
                    { text: 'ביטול', style: 'cancel' },
                    { text: 'מחק', onPress: () => deleteCarAndSendEmail() }
                ]
            );
        } catch (error) {
            console.error(error);
        }
    };

    const deleteCarAndSendEmail = async () => {
        try {
            const success = await deleteCar(currentUser.email, 'admin@gmail.com', carData.carNumber);

            if (success) {
                alert('המחיקה התבצעה בהצלחה');
                navigation.navigate('ProfilePage');
            } else {
                alert('רכב לא נמחק');
            }
        } catch (error) {
            console.error(error);
            // Show an error message to the user if something went wrong with the deletion or email sending.
            alert('אירעה שגיאה במחיקת הרכב');
        }
    };



    const transferCarConfirmation = async () => {
        try {
            const newOwnerEmail = await new Promise((resolve) => {
                Alert.prompt('העברת רכב', 'הזן את האימייל של המשתמש החדש:', (email) => {
                    resolve(email);
                });
            });

            setNewOwnerEmail(newOwnerEmail);
            const success = await transferCar(currentUser.email, newOwnerEmail, carData.carNumber);
            if (success) {
                alert('הועבר בהצלחה');
                navigation.navigate('ProfilePage');
            } else {
                alert('רכב לא הועבר');
            }
        } catch (error) {
            console.error(error);
        }
    };


    const Tahzuka = () => {
        navigation.navigate('TahzukaCar', { carData });

    };

    return (
        <View style={styles.container}>







            <View style={styles.coteret}>
                <Image style={styles.carImage} source={{ uri: carData.image }} />
                <Text style={styles.carName}> {carData.manufacturer}</Text>
                <Text style={styles.carName}> {carData.model}</Text>
                {carData.nickname && <Text style={styles.carName}> {"("}{carData.nickname}{")"}</Text>}
            </View>

            <View style={styles.hr} />

            <TouchableOpacity onPress={() => setModalVisible(true)}>
                <Image style={styles.biggerCarImage} source={{ uri: carData.image }} />
            </TouchableOpacity>

            {/* הצגה של תמונה בגדול ברגע לחיצה */}
            <Modal visible={modalVisible} transparent={true} onRequestClose={() => setModalVisible(false)}>
                <View style={styles.modalContainer}>
                    <Image style={styles.enlargedCarImage} source={{ uri: carData.image }} />
                    <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
                        <Text style={styles.closeButtonText}>סגור</Text>
                    </TouchableOpacity>
                </View>
            </Modal>
            {/* סוף אירוע הגדלת תמונה */}

            <View style={styles.theTwo}>
                {/* עדכון ק"מ */}
                <View style={styles.row}>
                    <TouchableOpacity style={styles.button} onPress={updateMileage}>
                        <Text style={styles.buttonText}>עדכן ק"מ</Text>
                    </TouchableOpacity>
                    <Text style={[styles.carDetails, styles.luxuryText, styles.kmShow]}>{mileageState} ק"מ</Text>
                </View>
                <View style={styles.hr} />
                {/* סוף עדכון ק"מ */}

                {/* עדכון טסט */}
                <View style={styles.row}>
                    <TouchableOpacity style={styles.button} onPress={updateTest}>
                        <Text style={styles.buttonText}>עדכן טסט</Text>
                    </TouchableOpacity>
                    <Text style={[styles.carDetails, styles.luxuryText, styles.kmShow]}>תוקף טסט: {testValidity}</Text>
                </View>
                <View style={styles.hr} />
                {/* סוף עדכון טסט */}
            </View>

            <Text style={[styles.carDetails, styles.luxuryText]}>מספר רכב: {carData.carNumber}</Text>
            <Text style={[styles.carDetails, styles.luxuryText]}>שנה: {carData.year}</Text>
            <Text style={[styles.carDetails, styles.luxuryText]}>יד: {carData.hand}</Text>

            <View style={styles.hr} />

            <TouchableOpacity style={styles.tahzukaButton} onPress={Tahzuka}>
                <Text style={styles.buttonText}>תחזוקה</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.transferButton} onPress={transferCarConfirmation}>
                <Text style={styles.buttonText}>העבר רכב</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.deleteButton} onPress={deleteCarConfirmation}>
                <Text style={styles.buttonText}>מחק רכב</Text>
            </TouchableOpacity>

        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        alignItems: 'center',
        marginVertical: 10,
        padding: 20,
        elevation: 5,
    },
    coteret: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        textAlign: "center",
        marginBottom: 10,
    },
    carImage: {
        width: 50,
        height: 50,
        borderRadius: 25,
        marginRight: 10,
    },
    carName: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    carDetails: {
        fontSize: 16,
        marginTop: 5,
        color: '#555',
    },
    hr: {
        borderBottomWidth: 1,
        borderBottomColor: '#aaa',
        marginVertical: 10,
        width: "100%",
    },
    biggerCarImage: {
        width: 200,
        height: 200,
        resizeMode: 'contain',
        marginBottom: 10,
    },
    luxuryText: {
        fontWeight: 'bold',
        color: '#222',
    },
    button: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        width: '40%',
        alignItems: 'center',
    },
    deleteButton: {
        backgroundColor: '#dc3545',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
        width: '80%',
        alignItems: 'center',
    },
    transferButton: {
        backgroundColor: '#28a745',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
        width: '80%',
        alignItems: 'center',
    },
    tahzukaButton: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
        width: '80%',
        alignItems: 'center',
    },
    buttonText: {
        color: 'black',
        fontWeight: 'bold',
    },
    row: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    kmShow: {
        paddingLeft: 30,
    },
    theTwo: {
        width: '100%',
    },
    modalContainer: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    closeButton: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
    },
    closeButtonText: {
        color: 'black',
        fontWeight: 'bold',
    },
    enlargedCarImage: {
        width: 350,
        height: 350,
        resizeMode: 'contain',
    },
});
